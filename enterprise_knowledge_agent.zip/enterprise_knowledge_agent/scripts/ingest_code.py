import sys
from app.ingestion.loaders import clone_or_open_repo
from app.ingestion.pipeline import ingest_dir

if __name__ == "__main__":
    repo = sys.argv[1] if len(sys.argv) > 1 else "data/code"
    path = clone_or_open_repo(repo)
    total = ingest_dir(str(path), "code")
    print(f"Indexed {total} code chunks")
