from app.ingestion.pipeline import ingest_dir

if __name__ == "__main__":
    total = 0
    total += ingest_dir("data/docs", "document")
    total += ingest_dir("data/tickets", "ticket")
    total += ingest_dir("data/code", "code")
    print(f"Indexed {total} chunks")
