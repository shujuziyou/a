import uuid
from typing import Any
import chromadb
from app.core.config import settings
from app.core.llm import embed_texts

_client = chromadb.PersistentClient(path=settings.VECTOR_DB_DIR)
_collection = _client.get_or_create_collection(name=settings.COLLECTION_NAME)


def add_documents(chunks: list[dict[str, Any]]) -> int:
    if not chunks:
        return 0
    texts = [c["text"] for c in chunks]
    embeddings = embed_texts(texts)
    ids = [c.get("id") or str(uuid.uuid4()) for c in chunks]
    metadatas = [c.get("metadata", {}) for c in chunks]
    _collection.add(ids=ids, documents=texts, embeddings=embeddings, metadatas=metadatas)
    return len(chunks)


def search(query: str, top_k: int = 8) -> list[dict[str, Any]]:
    q_emb = embed_texts([query])[0]
    result = _collection.query(query_embeddings=[q_emb], n_results=top_k)
    docs = result.get("documents", [[]])[0]
    metas = result.get("metadatas", [[]])[0]
    ids = result.get("ids", [[]])[0]
    distances = result.get("distances", [[]])[0]
    out = []
    for i, text in enumerate(docs):
        out.append({
            "id": ids[i],
            "text": text,
            "metadata": metas[i] or {},
            "score": None if not distances else 1 / (1 + distances[i]),
        })
    return out
