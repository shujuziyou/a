from fastapi import FastAPI
from app.agents.orchestrator import MultiAgentOrchestrator
from app.schemas.models import ChatRequest, ChatResponse, Source

app = FastAPI(title="Enterprise Knowledge Multi-Agent RAG")
orchestrator = MultiAgentOrchestrator()


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    result = orchestrator.answer(req.question, req.top_k)
    sources = []
    for c in result["chunks"]:
        m = c.get("metadata", {})
        sources.append(Source(
            source=m.get("source", "unknown"),
            type=m.get("type", "unknown"),
            chunk_id=c.get("id", ""),
            score=c.get("score"),
            preview=(c.get("text", "")[:220] + "...") if len(c.get("text", "")) > 220 else c.get("text", ""),
            metadata=m,
        ))
    return ChatResponse(answer=result["answer"], sources=sources, verification=result["verification"])
