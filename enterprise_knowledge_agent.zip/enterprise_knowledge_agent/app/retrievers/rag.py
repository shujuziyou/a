from app.core.config import settings
from app.storage.vector_store import search


def retrieve(question: str, top_k: int | None = None) -> list[dict]:
    return search(question, top_k or settings.TOP_K)


def format_context(chunks: list[dict]) -> str:
    lines = []
    for i, c in enumerate(chunks, 1):
        m = c.get("metadata", {})
        lines.append(
            f"[S{i}] type={m.get('type')} source={m.get('source')} chunk={c.get('id')}\n{c.get('text')}"
        )
    return "\n\n".join(lines)
