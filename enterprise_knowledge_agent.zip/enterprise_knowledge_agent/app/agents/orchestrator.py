from app.agents.retrieval_agent import RetrievalAgent
from app.agents.synthesis_agent import SynthesisAgent
from app.agents.verification_agent import VerificationAgent


class MultiAgentOrchestrator:
    def __init__(self):
        self.retriever = RetrievalAgent()
        self.synthesizer = SynthesisAgent()
        self.verifier = VerificationAgent()

    def answer(self, question: str, top_k: int | None = None) -> dict:
        chunks = self.retriever.run(question, top_k)
        answer = self.synthesizer.run(question, chunks)
        verification = self.verifier.run(question, answer, chunks)
        return {
            "answer": answer,
            "verification": verification,
            "chunks": chunks,
        }
