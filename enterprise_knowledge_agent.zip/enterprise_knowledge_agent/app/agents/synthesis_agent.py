from app.core.llm import chat
from app.retrievers.rag import format_context

SYSTEM = """
你是企业内部知识助手的归纳 Agent。
要求：
1. 只基于给定上下文回答，不要编造。
2. 答案要结构化，优先给结论、依据、操作步骤。
3. 涉及代码或系统排障时，给出可执行排查路径。
4. 引用来源编号，例如 [S1] [S3]。
5. 如果上下文不足，明确说明缺少什么信息。
""".strip()


class SynthesisAgent:
    name = "synthesis_agent"

    def run(self, question: str, chunks: list[dict]) -> str:
        context = format_context(chunks)
        return chat([
            {"role": "system", "content": SYSTEM},
            {"role": "user", "content": f"问题：{question}\n\n上下文：\n{context}"},
        ])
