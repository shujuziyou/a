from app.retrievers.rag import retrieve


class RetrievalAgent:
    name = "retrieval_agent"

    def run(self, question: str, top_k: int | None = None) -> list[dict]:
        return retrieve(question, top_k)
