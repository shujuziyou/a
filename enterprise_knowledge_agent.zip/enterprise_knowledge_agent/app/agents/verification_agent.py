from app.core.llm import chat
from app.retrievers.rag import format_context

SYSTEM = """
你是企业内部知识助手的校验 Agent。
任务：检查候选答案是否被上下文支持。
输出：
- 可信度：高/中/低
- 可能缺口：列出未被证据支持或需要补充的信息
- 修正建议：如果有幻觉风险，给出修正建议
""".strip()


class VerificationAgent:
    name = "verification_agent"

    def run(self, question: str, answer: str, chunks: list[dict]) -> str:
        return chat([
            {"role": "system", "content": SYSTEM},
            {"role": "user", "content": f"问题：{question}\n\n候选答案：\n{answer}\n\n上下文：\n{format_context(chunks)}"},
        ], temperature=0.0)
