from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    OPENAI_API_KEY: str
    LLM_MODEL: str = "gpt-4.1-mini"
    EMBEDDING_MODEL: str = "text-embedding-3-small"
    VECTOR_DB_DIR: str = ".chroma"
    COLLECTION_NAME: str = "enterprise_kb"
    TOP_K: int = 8

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
