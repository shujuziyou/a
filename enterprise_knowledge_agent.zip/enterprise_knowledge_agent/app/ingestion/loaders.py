from pathlib import Path
import json
from pypdf import PdfReader
from docx import Document
from git import Repo

TEXT_EXTS = {".txt", ".md", ".rst", ".json", ".yaml", ".yml", ".py", ".js", ".ts", ".tsx", ".java", ".go", ".rs", ".sql", ".sh"}
IGNORE_DIRS = {".git", "node_modules", "dist", "build", ".venv", "__pycache__"}


def load_file(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        reader = PdfReader(str(path))
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    if suffix == ".docx":
        doc = Document(str(path))
        return "\n".join(p.text for p in doc.paragraphs)
    if suffix == ".json":
        try:
            return json.dumps(json.loads(path.read_text(encoding="utf-8")), ensure_ascii=False, indent=2)
        except Exception:
            return path.read_text(encoding="utf-8", errors="ignore")
    if suffix in TEXT_EXTS:
        return path.read_text(encoding="utf-8", errors="ignore")
    return ""


def iter_files(root: str):
    root_path = Path(root)
    if not root_path.exists():
        return
    for p in root_path.rglob("*"):
        if any(part in IGNORE_DIRS for part in p.parts):
            continue
        if p.is_file() and (p.suffix.lower() in TEXT_EXTS or p.suffix.lower() in {".pdf", ".docx"}):
            yield p


def clone_or_open_repo(repo_url_or_path: str, dest: str = "data/code/_repo") -> Path:
    p = Path(repo_url_or_path)
    if p.exists():
        return p
    target = Path(dest)
    if target.exists():
        return target
    Repo.clone_from(repo_url_or_path, target)
    return target
