from app.ingestion.loaders import iter_files, load_file
from app.ingestion.chunker import chunk_text
from app.storage.vector_store import add_documents


def ingest_dir(root: str, doc_type: str) -> int:
    chunks = []
    for path in iter_files(root) or []:
        text = load_file(path)
        if not text.strip():
            continue
        chunks.extend(chunk_text(text, {
            "source": str(path),
            "type": doc_type,
            "filename": path.name,
        }))
    return add_documents(chunks)
