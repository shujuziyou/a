from langchain_text_splitters import RecursiveCharacterTextSplitter

splitter = RecursiveCharacterTextSplitter(
    chunk_size=1200,
    chunk_overlap=180,
    separators=["\n\n", "\n", "。", ".", " ", ""],
)


def chunk_text(text: str, metadata: dict) -> list[dict]:
    parts = splitter.split_text(text)
    chunks = []
    for idx, part in enumerate(parts):
        clean = part.strip()
        if len(clean) < 20:
            continue
        chunks.append({
            "text": clean,
            "metadata": {**metadata, "chunk_index": idx},
        })
    return chunks
