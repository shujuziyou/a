from pydantic import BaseModel, Field
from typing import Any


class ChatRequest(BaseModel):
    question: str = Field(..., min_length=1)
    top_k: int | None = None


class Source(BaseModel):
    source: str
    type: str
    chunk_id: str
    score: float | None = None
    preview: str
    metadata: dict[str, Any] = {}


class ChatResponse(BaseModel):
    answer: str
    sources: list[Source]
    verification: str
