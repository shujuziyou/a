# 企业内部知识问答 Agent（RAG + 多 Agent）

能力：
- 从文档、wiki、代码、历史工单入库
- Chroma 向量检索
- 多 Agent 协作：检索 Agent / 归纳 Agent / 校验 Agent
- FastAPI 提供问答接口

## 运行

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# 填写 OPENAI_API_KEY
```

放入资料：

```text
data/docs      # pdf / md / txt / docx
data/tickets   # 历史工单 txt/md/json
# 代码仓库可以放到 data/code，也可以用 ingest_code.py 指定路径
```

入库：

```bash
python scripts/ingest_all.py
```

启动 API：

```bash
uvicorn app.main:app --reload --port 8000
```

调用：

```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"question":"支付系统超时通常怎么排查？"}'
```
